"""Auto-generated user skill: read_skill_source_v2. Written by the save_new_skill tool — see
dana.core.skill_loader for how TOOL_SCHEMA/run() are loaded back."""

TOOL_SCHEMA = {
  "function": {
    "description": "Reads back the exact Python source code of a previously-saved user skill.",
    "name": "read_skill_source_v2",
    "parameters": {
      "properties": {},
      "required": [],
      "type": "object"
    }
  },
  "type": "function"
}


def run(args: dict) -> dict:
    # Your skill code here
    pass
