﻿Donna wake training artifacts were archived/removed from the repo root.

Kept:
  - donna.onnx (runtime wake model)
  - train_donna_local.py (re-run to regenerate data)

Removed from repo root (regenerable):
  audioset/, audioset_16k/, esc50_src/, esc50.zip
  MIT_environmental_impulse_responses/, mit_rirs/
  my_custom_model/, openwakeword/, piper-sample-generator/
  validation_set_features.npy, my_model.yaml
